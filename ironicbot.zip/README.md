# Ironicbot
A basicbot based Discord bot
Created by Perfect Irony

Made to run in docker with a MongoDB

# Built on Discord.py and Azure
Thanks to Bagel
